function [FL, FR, RL, RR, F_ROLL_CENTER, R_ROLL_CENTER, FL_KINEMATICS, FR_KINEMATICS, RL_KINEMATICS, RR_KINEMATICS, FL_DYNAMICS, RL_DYNAMICS] = ETR11_GET_POINTS(steering_wheel_angle, FL_COMPRESSION, FR_COMPRESSION, RL_COMPRESSION, RR_COMPRESSION, LOADED_RADIUS)
    % [wheel]_[componente 1]_[componente 2] (mah o menoh)
    % HP - Hardpoint
    % F - Front
    % R - Rear/Right
    % U - Upper
    % L - Lower
    % W - Wishbone
    % MC - Monocoque
    % KN - Knuckle
    % RKR - Rocker
    % PUSH - Pushrod
    % DPR - Damper
    % TR - Tie rod
    % KP - Kingpin

    %% FRONT HARDPOINTS (LEFT WHEEL)
        % SPINDLE
        HP_FL.SPINDLE_CENTER = [-100, -625, 203];  
        HP_FL.SPINDLE_INNER  = [-100, -567, 200.5];

        HP_FL.UW_KN          = [-98, -545, 294];
        HP_FL.LW_KN          = [-106 ,-585, 106]; 
       
        % WISHBONE - MONOCOQUE JOINT
        HP_FL.URW_MC         = [63, -247, 274.5]; 
        HP_FL.UFW_MC         = [-204, -248.5, 280]; 
        HP_FL.LRW_MC         = [96.5, -171, 136.5]; 
        HP_FL.LFW_MC         = [-226.5, -167.5, 123]; 

        % ROCKER AXIS
        HP_FL.RKR_1          = [-48, -179, 587]; 
        HP_FL.RKR_2          = [-48, -153.25, 552];

        front_rkr_axis = HP_FL.RKR_1 - HP_FL.RKR_2;
        f_a = 50;
        f_b = 85.5;
     
        % PUSH ROD
        HP_FL.PUSH_UW        = [-98, -516, 310];
        HP_FL.PUSH_RKR       = (HP_FL.RKR_2 + 0.5*front_rkr_axis) + f_a*[-1, 0, 0]; 

        % DAMPER
        HP_FL.DPR_RKR        = (HP_FL.RKR_2 + 0.5*front_rkr_axis) + f_b*(cross(f_a*[-1, 0, 0], front_rkr_axis))/norm(cross(f_a*[-1, 0, 0], front_rkr_axis));
        HP_FL.DPR_MC         = HP_FL.DPR_RKR + 175*[1, 0, 0];

        % ROCKER ROTATION
        rodrigues_rotation   = @(v, k, th) v*cos(th) + cross(k, v)*sin(th) + k*dot(k, v)*(1 - cos(th)); 
        HP_FL.DPR_RKR        = HP_FL.RKR_2 + rodrigues_rotation(HP_FL.DPR_RKR - HP_FL.RKR_2, front_rkr_axis/norm(front_rkr_axis), deg2rad(6.71663381));
        HP_FL.PUSH_RKR       = HP_FL.RKR_2 + rodrigues_rotation(HP_FL.PUSH_RKR - HP_FL.RKR_2, front_rkr_axis/norm(front_rkr_axis), deg2rad(6.71663381));
   
        % TIE ROD
        HP_FL.TR_UPRIGHT     = [-180, -560, 137];
        HP_FL.TR_RACK        = [-162, -176.5, 150.75];
        
        % PINION
        HP_FL.D_PINION       = 29;

        % ANTIROLL COORDIANTES
        HP_FL.AR_AXIS = [-150, -130, 634];

        f_arb_lever_length = 40;
        f_ar_rkr_lever_length = 70;

        front_rkr_aphotem_axis = (HP_FL.DPR_RKR - HP_FL.PUSH_RKR)/norm(HP_FL.DPR_RKR - HP_FL.PUSH_RKR);
        HP_FL.AR_LINK_RKR = HP_FL.PUSH_RKR + f_ar_rkr_lever_length*front_rkr_aphotem_axis;

        HP_FL.AR_LINK_ARB =  HP_FL.AR_AXIS - [0, 0, f_arb_lever_length];


   
        
   %% REAR HARDPOINTS (LEFT WHEEL)
        % Wheel spindle 
        HP_RL.SPINDLE_CENTER = [1435, -625, 203]; 
        HP_RL.SPINDLE_INNER  = [1435, -567, 200.5];
               
        % RL Knuckles
        HP_RL.UW_KN          = [1435, -540, 294]; 
        HP_RL.LW_KN          = [1433 ,-590, 111];
        
        % RL wishbones joints with monocoque
        HP_RL.URW_MC         = [1534, -283, 278.5];
        HP_RL.UFW_MC         = [1280.5, -280.5, 288.5];
        HP_RL.LRW_MC         = [1538.5, -274, 123.5];  
        HP_RL.LFW_MC         = [1259.5, -272.5, 144.5];

        

        % RL Rocker axis points
        HP_RL.RKR_1          = [1385, -259, 481];
        HP_RL.RKR_2          = [1385, -239.2, 447];

        rear_rkr_axis = HP_RL.RKR_1 - HP_RL.RKR_2;
        r_a = 50;
        r_b = 98.75;
        
        % RL Push rod
        HP_RL.PUSH_UW        = [1435, -520, 305];
        HP_RL.PUSH_RKR       = (HP_RL.RKR_2 + 0.5*rear_rkr_axis) + r_a*[1, 0, 0];
        
        % RL Damper
        HP_RL.DPR_RKR        = (HP_RL.RKR_2 + 0.5*rear_rkr_axis) + r_b*(cross(rear_rkr_axis, r_a*[1, 0, 0]))/norm(cross(r_a*[1, 0, 0], rear_rkr_axis));
        HP_RL.DPR_MC         = HP_RL.DPR_RKR + 175*[-1, 0, 0];

        % ROCKER ROTATION
        HP_RL.DPR_RKR        = HP_RL.RKR_2 + rodrigues_rotation(HP_RL.DPR_RKR - HP_RL.RKR_2, rear_rkr_axis/norm(rear_rkr_axis), deg2rad(-5.81206083));
        HP_RL.PUSH_RKR       = HP_RL.RKR_2 + rodrigues_rotation(HP_RL.PUSH_RKR - HP_RL.RKR_2, rear_rkr_axis/norm(rear_rkr_axis), deg2rad(-5.81206083));

        % RL Tie rod
        HP_RL.TR_UPRIGHT     = [1535, -595, 200];
        HP_RL.TR_RACK        = [1535, -275, 203.25];
        
        % Eje trasero fijo 
        HP_RL.D_PINION       = 0;

        % ANTIROLL COORDIANTES
        HP_RL.AR_AXIS = [1500, -200, 455];

        r_arb_lever_length = 50;
        r_ar_rkr_lever_length = 80;
       

        rear_rkr_aphotem_axis = (HP_RL.DPR_RKR - HP_RL.PUSH_RKR)/norm(HP_RL.DPR_RKR - HP_RL.PUSH_RKR);
        HP_RL.AR_LINK_RKR = HP_RL.PUSH_RKR + r_ar_rkr_lever_length*rear_rkr_aphotem_axis;

        HP_RL.AR_LINK_ARB = HP_RL.AR_AXIS + [0, 0, r_arb_lever_length];


        

    % FRONT HARDPOINTS (RIGHT WHEEL). LEFT INVERTIDOS, SOLO TOCAR LOS DE LA RUEDA IZQUIERDA, NO TOCAR ESTO
        HP_FR.SPINDLE_CENTER = HP_FL.SPINDLE_CENTER .* [1, -1, 1]; 
        HP_FR.SPINDLE_INNER  = HP_FL.SPINDLE_INNER  .* [1, -1, 1];
        HP_FR.UW_KN          = HP_FL.UW_KN          .* [1, -1, 1]; 
        HP_FR.LW_KN          = HP_FL.LW_KN          .* [1, -1, 1];
        HP_FR.URW_MC         = HP_FL.URW_MC         .* [1, -1, 1];
        HP_FR.UFW_MC         = HP_FL.UFW_MC         .* [1, -1, 1];
        HP_FR.LRW_MC         = HP_FL.LRW_MC         .* [1, -1, 1];
        HP_FR.LFW_MC         = HP_FL.LFW_MC         .* [1, -1, 1];
        HP_FR.PUSH_UW        = HP_FL.PUSH_UW        .* [1, -1, 1];
        HP_FR.PUSH_RKR       = HP_FL.PUSH_RKR       .* [1, -1, 1];
        HP_FR.RKR_1          = HP_FL.RKR_1          .* [1, -1, 1];
        HP_FR.RKR_2          = HP_FL.RKR_2          .* [1, -1, 1];
        HP_FR.DPR_RKR        = HP_FL.DPR_RKR        .* [1, -1, 1];
        HP_FR.DPR_MC         = HP_FL.DPR_MC         .* [1, -1, 1]; 
        HP_FR.TR_UPRIGHT     = HP_FL.TR_UPRIGHT     .* [1, -1, 1];
        HP_FR.TR_RACK        = HP_FL.TR_RACK        .* [1, -1, 1];
        HP_FR.D_PINION       = HP_FL.D_PINION;
        HP_FR.AR_AXIS        = HP_FL.AR_AXIS        .* [1, -1, 1];
        HP_FR.AR_LINK_RKR    = HP_FL.AR_LINK_RKR    .* [1, -1, 1];
        HP_FR.AR_LINK_ARB    = HP_FL.AR_LINK_ARB    .* [1, -1, 1];


    % REAR HARDPOINTS (RIGHT WHEEL). LEFT INVERTIDOS, SOLO TOCAR LOS DE LA RUEDA IZQUIERDA, NO TOCAR ESTO
        HP_RR.SPINDLE_CENTER = HP_RL.SPINDLE_CENTER .* [1, -1, 1];
        HP_RR.SPINDLE_INNER  = HP_RL.SPINDLE_INNER .* [1, -1, 1];
        HP_RR.UW_KN          = HP_RL.UW_KN .* [1, -1, 1];
        HP_RR.LW_KN          = HP_RL.LW_KN .* [1, -1, 1];
        HP_RR.URW_MC         = HP_RL.URW_MC .* [1, -1, 1];
        HP_RR.UFW_MC         = HP_RL.UFW_MC .* [1, -1, 1];
        HP_RR.LRW_MC         = HP_RL.LRW_MC .* [1, -1, 1];
        HP_RR.LFW_MC         = HP_RL.LFW_MC .* [1, -1, 1];
        HP_RR.PUSH_UW        = HP_RL.PUSH_UW .* [1, -1, 1];
        HP_RR.PUSH_RKR       = HP_RL.PUSH_RKR .* [1, -1, 1];
        HP_RR.RKR_1          = HP_RL.RKR_1 .* [1, -1, 1];
        HP_RR.RKR_2          = HP_RL.RKR_2 .* [1, -1, 1];
        HP_RR.DPR_RKR        = HP_RL.DPR_RKR .* [1, -1, 1];
        HP_RR.DPR_MC         = HP_RL.DPR_MC .* [1, -1, 1];
        HP_RR.TR_UPRIGHT     = HP_RL.TR_UPRIGHT .* [1, -1, 1];
        HP_RR.TR_RACK        = HP_RL.TR_RACK .* [1, -1, 1];
        HP_RR.D_PINION       = 0;
        HP_RR.AR_AXIS        = HP_RL.AR_AXIS        .* [1, -1, 1];
        HP_RR.AR_LINK_RKR    = HP_RL.AR_LINK_RKR    .* [1, -1, 1];
        HP_RR.AR_LINK_ARB    = HP_RL.AR_LINK_ARB    .* [1, -1, 1];


    %% LLAMADA SOLVER PARA CADA RUEDA
    FL = ETR11_KINEMATICS_SOLVER(HP_FL, steering_wheel_angle, FL_COMPRESSION, LOADED_RADIUS);
    FR = ETR11_KINEMATICS_SOLVER(HP_FR, steering_wheel_angle, FR_COMPRESSION, LOADED_RADIUS);
    RL = ETR11_KINEMATICS_SOLVER(HP_RL, 0, RL_COMPRESSION, LOADED_RADIUS);
    RR = ETR11_KINEMATICS_SOLVER(HP_RR, 0, RR_COMPRESSION, LOADED_RADIUS);

    % LLAMADA FUNCIÓN ROLL CENTERS
    [F_ROLL_CENTER, R_ROLL_CENTER] = roll_centers_calc(FL, FR, RL, RR);

    % LLAMADA FUNCIÓN DATOS 
    [FL_KINEMATICS, FR_KINEMATICS, RL_KINEMATICS, RR_KINEMATICS] = solver_kinematics_data(FL, FR, RL, RR);

    % FUERZA CONTACT PATCH (FL SOLO DE MOMENTO)
    FL_CONTACT_PATCH_FORCE = [2000, 2382, 1500];
    RL_CONTACT_PATCH_FORCE = [-2876, 2681, 5093];


    % FUNCIÓN FUERZAS
    FL_DYNAMICS = ETR11_DYNAMICS_SOLVER(FL, FL_CONTACT_PATCH_FORCE);
    % FR_DYNAMICS = ETR11_DYNAMICS_SOLVER(FR, FR_CONTACT_PATCH_FORCE);
    
    RL_DYNAMICS = ETR11_DYNAMICS_SOLVER(RL, RL_CONTACT_PATCH_FORCE);
    % RR_DYNAMICS = ETR11_DYNAMICS_SOLVER(RR, RR_CONTACT_PATCH_FORCE);


end

