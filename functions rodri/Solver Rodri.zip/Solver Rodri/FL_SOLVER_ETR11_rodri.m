function[FL] = FL_SOLVER_ETR11_rodri(steering_wheel_angle, FL_DPR_COMPRESSION)
    % Front left suspension and steering geometry
    % [wheel]_[componente 1]_[componente 2]
    % F - Front
    % R - Rear/Right
    % U - Upper
    % L - Lower
    % W - Wishbone
    % MC - Monocoque
    % KN - Knuckle
    % RKR - Rocker
    % PUSH - Pushrod
    % DPR - Damper
    % UPRIGHT - Upright (mangueta)
    % TR - Tie rod
    % RACK - Rack
    % KP - Kingpin
    
    
    %% COORDINATES DEFINITIONS. POINTS
        % Wheel spindle 
        FL_SPINDLE_CENTER = [-100, -625, 203]; 
        FL_SPINDLE_INNER = [-100, -561.5, 200.5];
        FL_SPINDLE = (FL_SPINDLE_INNER - FL_SPINDLE_CENTER)/norm(FL_SPINDLE_INNER - FL_SPINDLE_CENTER);
        % Contact patch
        FL_CONTACT_PATCH = FL_SPINDLE_CENTER + 203*(cross(cross(FL_SPINDLE, [0, 0, -1]), FL_SPINDLE)/norm(cross(cross(FL_SPINDLE, [0, 0, -1]), FL_SPINDLE)));
        % FL Knuckles
        FL_UW_KN = [-80, -520, 294]; 
        FL_LW_KN = [-100 ,-571, 111];
        
        % FL wishbones joints with monocoque
        FL_URW_MC = [80, -225, 268];
        FL_UFW_MC = [-210, -225, 277];
        FL_LRW_MC = [85, -225, 136];
        FL_LFW_MC = [-210, -225, 123];
        
        % FL Push rod
        FL_PUSH_UW = [-80, -523, 305];
        FL_PUSH_RKR = [-91, -193.5, 558];
        
        % FL Rocker axis points
        FL_RKR_1 = [-26, -186.5, 587];
        FL_RKR_2 = [-26, -164, 552];
        
        % FL Damper
        FL_DPR_RKR = [-51, -112, 610];
        FL_DPR_MC = [164, -112, 610];

        % FL Tie rod
        FL_TR_UPRIGHT = [-180, -560, 140];
        FL_TR_RACK = [-170, -225, 150.68];
        
    %% INPUTS STEERING
        D_PINION = 35;
        RACK_DISPLACEMENT = deg2rad(steering_wheel_angle)*D_PINION/2;
        FL_TR_RACK_FINAL_POINT = FL_TR_RACK + [0, RACK_DISPLACEMENT, 0];
      
    %% FIXED DISTANCES DEFINITIONS
        % Upper wishbone
        F_URW_LENGTH = norm(FL_URW_MC - FL_UW_KN);
        F_UFW_LENGTH = norm(FL_UFW_MC - FL_UW_KN);
    
        % Lower wishbone
        F_LRW_LENGTH = norm(FL_LRW_MC - FL_LW_KN);
        F_LFW_LENGTH = norm(FL_LFW_MC - FL_LW_KN);
    
        % Push rod
        F_PUSH_LENGTH = norm(FL_PUSH_UW - FL_PUSH_RKR);
    
        % Tie rod
        F_TR_LENGTH = norm(FL_TR_UPRIGHT - FL_TR_RACK);
        
        % Upright
        F_KP_LENGTH = norm(FL_UW_KN - FL_LW_KN);
        F_UW_to_TR    = norm(FL_UW_KN - FL_TR_UPRIGHT);
        F_LW_to_TR    = norm(FL_LW_KN - FL_TR_UPRIGHT);
        F_UW_to_PUSH  = norm(FL_UW_KN - FL_PUSH_UW);
        F_LW_to_PUSH  = norm(FL_LW_KN - FL_PUSH_UW);
        F_TR_to_PUSH  = norm(FL_TR_UPRIGHT - FL_PUSH_UW);  
    
        % Damper initial length
        DPR_LENGTH = norm(FL_DPR_MC - FL_DPR_RKR);
    
    
    %% AXIS DEFINITIONS. NORMALIZED VECTORS
        % FL Kingpin axis. Definido hacia abajo, para tener giro a derechas positivo.
        FL_KP = (FL_LW_KN - FL_UW_KN)/norm((FL_LW_KN - FL_UW_KN));
        
        % FL Wishbone axis. Definido para valores de rotación positivos en compresión
        FL_UW_AXIS = (FL_UFW_MC - FL_URW_MC)/norm(FL_UFW_MC - FL_URW_MC);
        FL_LW_AXIS = (FL_LFW_MC - FL_LRW_MC)/norm(FL_LFW_MC - FL_LRW_MC);
        
        % FL rocker axis. Definido para valores positivos de rotación en compresión.
        FL_RKR_AXIS = (FL_RKR_2 - FL_RKR_1)/norm(FL_RKR_2 - FL_RKR_1);
        
    %% PLANES DEFINITIONS. [A, B, C, D].
        % FL wishbones planes
            % Upper
            FL_UW_PLANE = cross(FL_URW_MC - FL_UW_KN, FL_UFW_MC - FL_UW_KN);
            FL_UW_PLANE = FL_UW_PLANE / norm(FL_UW_PLANE);
            FL_UW_PLANE(4) = -dot(FL_UW_PLANE, FL_UW_KN);
        
            % Lower
            FL_LW_PLANE = cross(FL_LRW_MC - FL_LW_KN, FL_LFW_MC - FL_LW_KN);
            FL_LW_PLANE = FL_LW_PLANE / norm(FL_LW_PLANE);
            FL_LW_PLANE(4) = -dot(FL_LW_PLANE, FL_LW_KN);
    
        % Rocker
        FL_RKR_PLANE = cross(FL_RKR_2 - FL_RKR_1, FL_DPR_RKR - FL_RKR_1);
        FL_RKR_PLANE = FL_RKR_PLANE / norm(FL_RKR_PLANE);
        FL_RKR_PLANE(4) = -dot(FL_RKR_PLANE, FL_DPR_RKR);
    
    
    %% SOLVER
    %% Definición de la compresión del rocker y la rotación del rocker asociada. Formula de Rodrigues. 
    % - Incógnita(s): ángulo rotación rocker.
    % - Restricción(es): longitud damper (distancia entre FL_DPR_RKR y FL_DPR_MC)
        % vectores a rotar del rocker. Punto referencia FL_RKR_2 para Rodrigues.
        FL_RKR_AXIS_2_to_DPR = FL_DPR_RKR - FL_RKR_2 ;
        FL_RKR_AXIS_2_to_PUSH = FL_PUSH_RKR - FL_RKR_2 ;
        
        % Fórmula de Rodrigues
        rodrigues_rotation_NEW_FUNCTION = @(v, k, th) v*cos(th) + cross(k, v)*sin(th) + k*dot(k, v)*(1 - cos(th)); 
        
        % Función a solucionar. Busca el ángulo que hace que se consiga la longitud total deseada del damper
        FL_RKR_SOLVE_NEW_FUNCTION = @(FL_RKR_ANGLE) norm((FL_RKR_2 + rodrigues_rotation_NEW_FUNCTION(FL_RKR_AXIS_2_to_DPR, FL_RKR_AXIS, FL_RKR_ANGLE)) - FL_DPR_MC) - (DPR_LENGTH - FL_DPR_COMPRESSION);
        
        % Solucionar ecuación anterior igualada a 0.
        FL_RKR_ANGLE = fzero(FL_RKR_SOLVE_NEW_FUNCTION, 0);
        % Definir nueva posición de los extremos del rocker.
        FL_DPR_RKR_FINAL_POINT = FL_RKR_2 + rodrigues_rotation_NEW_FUNCTION(FL_RKR_AXIS_2_to_DPR, FL_RKR_AXIS, FL_RKR_ANGLE);
        FL_PUSH_RKR_FINAL_POINT = FL_RKR_2 + rodrigues_rotation_NEW_FUNCTION(FL_RKR_AXIS_2_to_PUSH, FL_RKR_AXIS, FL_RKR_ANGLE);
    
    
    %% Definición de la nueva posición de Kingpin, con el cálculo de ángulos de wishbones asociado. Fórmula de RODRIGUEEEESSSSS
    % - Incógnita(s): Ángulo rotación upper wishbone, ángulo de rotación lower wishbone y ángulo de rotación mangueta alrededor del kingpin.
    % - Restricción(es): Distancia entre knuckles, longitud pushrod y longitud tie.
        % Ecuación 1. Distancia entre kunckles.
            % Vectores a rotar.
            FL_URW_MC_to_UW_KN = FL_UW_KN - FL_URW_MC; % vector a rotar upper wishbone. Referencia Rodrigues rear mc joint.
            FL_LRW_MC_to_LW_KN = FL_LW_KN - FL_LRW_MC; % vector a rota lower wishbone- Referencia Rodrigues rear mc joint.
            
            % Rotaciones
            FL_UW_KN_NEW_FUNCTION = @(FL_UW_ANGLE) FL_URW_MC + rodrigues_rotation_NEW_FUNCTION(FL_URW_MC_to_UW_KN, FL_UW_AXIS, FL_UW_ANGLE);
            FL_LW_KN_NEW_FUNCTION = @(FL_LW_ANGLE) FL_LRW_MC + rodrigues_rotation_NEW_FUNCTION(FL_LRW_MC_to_LW_KN, FL_LW_AXIS, FL_LW_ANGLE);
            % Función a solucionar. Distancia entre kunckles.
            FL_KNS_SOLVE_NEW_FUNCTION = @(x) norm(FL_UW_KN_NEW_FUNCTION(x(1)) - FL_LW_KN_NEW_FUNCTION(x(2))) - F_KP_LENGTH; % x(1) es el ángulo del UW, x(2) es el ángulo de LW
            FL_KP_NEW_FUNCTION = @(FL_UW_ANGLE, FL_LW_ANGLE) (FL_LW_KN_NEW_FUNCTION(FL_LW_ANGLE) - FL_UW_KN_NEW_FUNCTION(FL_UW_ANGLE))/norm(FL_LW_KN_NEW_FUNCTION(FL_LW_ANGLE) - FL_UW_KN_NEW_FUNCTION(FL_UW_ANGLE));
       
        % Ecuación 2. Longitud tie.
            FL_STEER_ARM = FL_TR_UPRIGHT - FL_LW_KN;
           
            h_TR = dot(FL_STEER_ARM, FL_KP); % Cuánto sube el brazo por el eje
            v_rad_TR = FL_STEER_ARM - h_TR * FL_KP; % El resto del brazo (perpendicular)
    
            % 2. Rotación acoplada: inclina con el eje y luego gira x(3)
            FL_TR_UPRIGHT_NEW_FUNCTION = @(x) FL_LW_KN_NEW_FUNCTION(x(2)) +  h_TR * FL_KP_NEW_FUNCTION(x(1), x(2)) + rodrigues_rotation_NEW_FUNCTION(v_rad_TR, FL_KP_NEW_FUNCTION(x(1), x(2)), x(3));
    
            % Ecuación a resolver
            FL_TR_SOLVE_NEW_FUNCTION = @(x) norm(FL_TR_UPRIGHT_NEW_FUNCTION(x) - FL_TR_RACK_FINAL_POINT) - F_TR_LENGTH;
        
        % Ecuación 3. Longitud push.
            % Vector a rotar. (mc hasta push-uptight)
            FL_PUSH_MC = FL_PUSH_UW - FL_URW_MC;
    
            % Rotación.
            FL_PUSH_UW_NEW_FUNCTION = @(x) FL_URW_MC + rodrigues_rotation_NEW_FUNCTION(FL_PUSH_MC, FL_UW_AXIS, x(1));
    
            % Ecuación a solucionar
            FL_PUSH_SOLVE_NEW_FUNCTION = @(x) norm(FL_PUSH_UW_NEW_FUNCTION(x) - FL_PUSH_RKR_FINAL_POINT) - F_PUSH_LENGTH;
    
        % RESOLUCIÓN FINAL
        FL_TOTAL_SOLVE_NEW_FUNCTION = @(x) [FL_KNS_SOLVE_NEW_FUNCTION(x); FL_TR_SOLVE_NEW_FUNCTION(x); FL_PUSH_SOLVE_NEW_FUNCTION(x)];
        x = fsolve(FL_TOTAL_SOLVE_NEW_FUNCTION, [0, 0, 0]);
        
        FL_UW_ANGLE = rad2deg(x(1));
        FL_LW_ANGLE = rad2deg(x(2));
        FL_TOTAL_STEER = rad2deg(x(3));
    
    
    %% PUNTOS ACTUALIZADOS
         % KNUCKLES
         FL_UW_KN_FINAL_POINT = FL_UW_KN_NEW_FUNCTION(x(1));
         FL_LW_KN_FINAL_POINT = FL_LW_KN_NEW_FUNCTION(x(2));
         % Kingpin nuevo
         FL_KP_FINAL_POINT = FL_KP_NEW_FUNCTION(x(1), x(2));
    
         % TIE ROD
         FL_TR_RACK_FINAL_POINT;
         FL_TR_UPRIGHT_FINAL_POINT = FL_TR_UPRIGHT_NEW_FUNCTION(x);
         
         % ROCKER
         FL_DPR_RKR_FINAL_POINT;    
         % PUSH
         FL_PUSH_UW_FINAL_POINT = FL_PUSH_UW_NEW_FUNCTION(x);
         FL_PUSH_RKR_FINAL_POINT;
    
    
    % ROTACIÓN SPINDLE
        % DESCOMPOSICIÓN AXIAL Y RADIAL RESPECTO A KINGPIN SPINDLE POINT CENTER
            FL_LW_KN_to_SPINDLE_CENTER = FL_SPINDLE_CENTER - FL_LW_KN; % Vector inicial de lower knuckle a spindle center
        
            % Descomposición vector en componente axial y radial sobre kingpin
            FL_LW_KN_to_SPINDLE_CENTER_axial_KP = dot(FL_LW_KN_to_SPINDLE_CENTER, FL_KP); % comoponente axial
            FL_LW_KN_to_SPINDLE_CENTER_radial_KP = FL_LW_KN_to_SPINDLE_CENTER - FL_LW_KN_to_SPINDLE_CENTER_axial_KP*FL_KP; % componente radial
        
        % DESCOMPOSICIÓN AXIAL Y RADIAL RESPECTO A KINGPIN SPINDLE POINT INNER.
            FL_LW_KN_to_SPINDLE_INNER = FL_SPINDLE_INNER - FL_LW_KN; % Vector inicial de lower knuckle a spindle center
        
            % Descomposición vector en componente axial y radial sobre kingpin
            FL_LW_KN_to_SPINDLE_INNER_axial_KP = dot(FL_LW_KN_to_SPINDLE_INNER, FL_KP); % comoponente axial
            FL_LW_KN_to_SPINDLE_INNER_radial_KP = FL_LW_KN_to_SPINDLE_INNER - FL_LW_KN_to_SPINDLE_INNER_axial_KP*FL_KP; % componente radial
        
        % Nuevo spindle center
        FL_SPINDLE_CENTER_FINAL_POINT = FL_LW_KN_FINAL_POINT + FL_LW_KN_to_SPINDLE_CENTER_axial_KP * FL_KP_FINAL_POINT + rodrigues_rotation_NEW_FUNCTION(FL_LW_KN_to_SPINDLE_CENTER_radial_KP, FL_KP_FINAL_POINT, x(3));
        
        % Nuevo spindle inner
        FL_SPINDLE_INNER_FINAL_POINT = FL_LW_KN_FINAL_POINT + FL_LW_KN_to_SPINDLE_INNER_axial_KP * FL_KP_FINAL_POINT + rodrigues_rotation_NEW_FUNCTION(FL_LW_KN_to_SPINDLE_INNER_radial_KP, FL_KP_FINAL_POINT, x(3));
        
        % Nuevo spindle
        FL_SPINDLE_FINAL = (FL_SPINDLE_INNER_FINAL_POINT - FL_SPINDLE_CENTER_FINAL_POINT)/norm(FL_SPINDLE_INNER_FINAL_POINT - FL_SPINDLE_CENTER_FINAL_POINT); % nuevo vector spindle
    
    % Nuevo contact patch
    v_down_wheel = cross(cross(FL_SPINDLE_FINAL, [0, 0, -1]), FL_SPINDLE_FINAL);
    FL_CONTACT_PATCH_FINAL_POINT = FL_SPINDLE_CENTER_FINAL_POINT + 203 * (v_down_wheel / norm(v_down_wheel));
    
    % Intersección del Kingpin con el suelo
    t_ground = -FL_LW_KN_FINAL_POINT(3) / FL_KP_FINAL_POINT(3);
    FL_KP_GROUND_FINAL_POINT = FL_LW_KN_FINAL_POINT + t_ground * FL_KP_FINAL_POINT;

    FL_CAMBER = asind(FL_SPINDLE_FINAL(3))


    [~,~,~,~,~,~,~,~,~,~,~,~,Re] = mfeval_function(270*9.81/4, 0, 0, FL_CAMBER, 0)

    z_offset = [0, 0, FL_SPINDLE_CENTER_FINAL_POINT(3) - Re*1000];

    FL.UW_KN         = FL_UW_KN_FINAL_POINT - z_offset;
    FL.LW_KN         = FL_LW_KN_FINAL_POINT - z_offset;
    FL.TR_RACK       = FL_TR_RACK_FINAL_POINT - z_offset;
    FL.TR_UPRIGHT    = FL_TR_UPRIGHT_FINAL_POINT - z_offset;
    FL.DPR_RKR       = FL_DPR_RKR_FINAL_POINT - z_offset;
    FL.PUSH_UW       = FL_PUSH_UW_FINAL_POINT - z_offset;
    FL.PUSH_RKR      = FL_PUSH_RKR_FINAL_POINT - z_offset;
    FL.SPINDLE_CENTER= FL_SPINDLE_CENTER_FINAL_POINT - z_offset;
    FL.SPINDLE_INNER = FL_SPINDLE_INNER_FINAL_POINT - z_offset;
    FL.DPR_MC        = FL_DPR_MC - z_offset;
    FL.RKR_AXIS_1    = FL_RKR_1 - z_offset;
    FL.RKR_AXIS_2    = FL_RKR_2 - z_offset;
    FL.CONTACT_PATCH = FL_CONTACT_PATCH_FINAL_POINT - z_offset;
    FL.KP_GROUND     = FL_KP_GROUND_FINAL_POINT - z_offset;
        
   
    
end



    












   


