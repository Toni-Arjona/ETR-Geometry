function [FL_KINEMATICS, FR_KINEMATICS, RL_KINEMATICS, RR_KINEMATICS] = solver_kinematics_data(FL, FR, RL, RR)
    %% STEER (TOE)
        FL_KINEMATICS.STEER = atan2d(-FL.SPINDLE(1),  FL.SPINDLE(2));
        FR_KINEMATICS.STEER = atan2d( FR.SPINDLE(1), -FR.SPINDLE(2));
        RL_KINEMATICS.STEER = atan2d(-RL.SPINDLE(1),  RL.SPINDLE(2));
        RR_KINEMATICS.STEER = atan2d( RR.SPINDLE(1), -RR.SPINDLE(2));
        
    %% CAMBER
        FL_KINEMATICS.CAMBER = atan2d(FL.SPINDLE(3),  FL.SPINDLE(2));
        FR_KINEMATICS.CAMBER = atan2d(FR.SPINDLE(3), -FR.SPINDLE(2));
        RL_KINEMATICS.CAMBER = atan2d(RL.SPINDLE(3),  RL.SPINDLE(2));
        RR_KINEMATICS.CAMBER = atan2d(RR.SPINDLE(3), -RR.SPINDLE(2));
 
    %% KINGPIN - KPI y Caster
        FL_KINEMATICS.KPI = atan2d(-FL.KP(2), -FL.KP(3));
        FR_KINEMATICS.KPI = atan2d( FR.KP(2), -FR.KP(3));
        RL_KINEMATICS.KPI = atan2d(-RL.KP(2), -RL.KP(3));
        RR_KINEMATICS.KPI = atan2d( RR.KP(2), -RR.KP(3));
        
    %% CASTER (Plano XZ). 
        FL_KINEMATICS.CASTER = atan2d(-FL.KP(1), -FL.KP(3));
        FR_KINEMATICS.CASTER = atan2d(-FR.KP(1), -FR.KP(3));
        RL_KINEMATICS.CASTER = atan2d(-RL.KP(1), -RL.KP(3));
        RR_KINEMATICS.CASTER = atan2d(-RR.KP(1), -RR.KP(3));

  %% SCRUB RADIUS Y MECHANICAL TRAIL DINÁMICOS (Proyección sobre Eje Y local 2D)
        
        % 1. Extraemos el Eje Y local (Proyección 2D del Spindle)
        S_FL = [FL.SPINDLE(1), FL.SPINDLE(2), 0]; u_Y_FL = S_FL / norm(S_FL);
        S_FR = [FR.SPINDLE(1), FR.SPINDLE(2), 0]; u_Y_FR = S_FR / norm(S_FR);
        S_RL = [RL.SPINDLE(1), RL.SPINDLE(2), 0]; u_Y_RL = S_RL / norm(S_RL);
        S_RR = [RR.SPINDLE(1), RR.SPINDLE(2), 0]; u_Y_RR = S_RR / norm(S_RR);

        % 2. Vectores de distancia geométrica (KP_FLOOR respecto al CONTACT_PATCH)
        D_FL = [FL.KP_FLOOR(1) - FL.CONTACT_PATCH(1), FL.KP_FLOOR(2) - FL.CONTACT_PATCH(2), 0];
        D_FR = [FR.KP_FLOOR(1) - FR.CONTACT_PATCH(1), FR.KP_FLOOR(2) - FR.CONTACT_PATCH(2), 0];
        D_RL = [RL.KP_FLOOR(1) - RL.CONTACT_PATCH(1), RL.KP_FLOOR(2) - RL.CONTACT_PATCH(2), 0];
        D_RR = [RR.KP_FLOOR(1) - RR.CONTACT_PATCH(1), RR.KP_FLOOR(2) - RR.CONTACT_PATCH(2), 0];

        % 3. CÁLCULO ESTRICTO DE DISTANCIAS
        % SCRUB = Distancia a lo largo del eje Y (Producto escalar)
        FL_KINEMATICS.SCRUB = dot(D_FL, u_Y_FL);
        FR_KINEMATICS.SCRUB = dot(D_FR, u_Y_FR);
        RL_KINEMATICS.SCRUB = dot(D_RL, u_Y_RL);
        RR_KINEMATICS.SCRUB = dot(D_RR, u_Y_RR);
        
        % TRAIL = Distancia perpendicular al eje Y (Producto vectorial en 2D)
        % Se ajusta el signo del lado derecho para que un KP adelantado dé Trail positivo en ambos lados
        Tr_FL = cross(u_Y_FL, D_FL); FL_KINEMATICS.TRAIL = Tr_FL(3);
        Tr_FR = cross(u_Y_FR, D_FR); FR_KINEMATICS.TRAIL = -Tr_FR(3);
        Tr_RL = cross(u_Y_RL, D_RL); RL_KINEMATICS.TRAIL = Tr_RL(3);
        Tr_RR = cross(u_Y_RR, D_RR); RR_KINEMATICS.TRAIL = -Tr_RR(3);
    
    %% JACKING RATE (Tasa de elevación instantánea)   
    % FRONT LEFT
        R_CP_FL = FL.CONTACT_PATCH - FL.LW_KN;
        V_Jacking_FL = cross(FL.KP, R_CP_FL);
        FL_KINEMATICS.JACKING_RATE = V_Jacking_FL(3) * (pi/180); % [mm/deg]
        
    % FRONT RIGHT
        R_CP_FR = FR.CONTACT_PATCH - FR.LW_KN;
        V_Jacking_FR = cross(FR.KP, R_CP_FR);
        FR_KINEMATICS.JACKING_RATE = V_Jacking_FR(3) * (pi/180); % [mm/deg]
        
    % REAR LEFT
        R_CP_RL = RL.CONTACT_PATCH - RL.LW_KN;
        V_Jacking_RL = cross(RL.KP, R_CP_RL);
        RL_KINEMATICS.JACKING_RATE = V_Jacking_RL(3) * (pi/180); % [mm/deg]
        
    % REAR RIGHT
        R_CP_RR = RR.CONTACT_PATCH - RR.LW_KN;
        V_Jacking_RR = cross(RR.KP, R_CP_RR);
        RR_KINEMATICS.JACKING_RATE = V_Jacking_RR(3) * (pi/180); % [mm/deg]
end


